// index.mjs - Modular AWS SDK v3 + X-Ray Middleware Pattern
import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";
import AWSXRay from "aws-xray-sdk-core";

// 1. Initialize the base modular S3 Client wrapper
const baseS3Client = new S3Client({});

// 👑 The Modern Magic Hook: Instrument the specific client instance via the X-Ray SDK middleware
const s3Client = AWSXRay.captureAWSv3Client(baseS3Client);

export const handler = async (event) => {
    try {
        // 2. Instantiate the isolated, tree-shakable command bundle
        const command = new ListBucketsCommand({});
        
        // 3. Execute the payload down the wire
        const data = await s3Client.send(command);
        
        return {
            statusCode: 200,
            body: JSON.stringify({ 
                message: "Buckets gathered with SDK v3, chief!", 
                buckets: data.Buckets 
            })
        };
    } catch (err) {
        return {
            statusCode: err.$metadata?.httpStatusCode || 500,
            body: JSON.stringify({ error: err.message })
        };
    }
};
